package com.uisrael.proyectoapi.infraestructura.persistencia.jpa;

import java.io.Serializable;	

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "accesorios")
public class AccesorioJpa implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idAccesorio;
    private String descripcion;
    private boolean incluido;
    
    @ManyToOne
	@JoinColumn(name = "fkEquipo")
	private EquipoJpa fkEquipo;
}
